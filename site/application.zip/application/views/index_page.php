<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Cooking teacher</title>
 
</head>
<body>

<div id="container">
 

</body>
</html>