</main>

<!-- Modal -->
<div class="modal fade" id="staticAuth" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticAuthpLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="staticAuthpLabel">Авторизоваться</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Email адрес</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <small id="emailHelp" class="form-text text-muted">Данные не распространяются третьим лицам.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Введите пароль</label>
    <input type="password" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Политика конфинциальности данных</label>
  </div>
  <button type="submit" class="btn btn-primary">Войти</button>
</form>
      </div>
    
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="staticRegister" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-labelledby="staticRegisterLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title text-center" id="staticRegisterLabel">Зарегистрироваться</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form>
  <div class="form-group">
    <label for="exampleInputEmail1">Email адрес</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <small id="emailHelp" class="form-text text-muted">Данные не распространяются третьим лицам.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Введите пароль</label>
    <input type="password" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Политика конфинциальности данных</label>
  </div>
  <button type="submit" class="btn btn-primary">Регистрация</button>
</form>
      </div>
     
    </div>
  </div>
</div>
</body>
</html>