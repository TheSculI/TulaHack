<div class="row">
<?foreach($recipes as $recipe):?>
<div class="col-3">
    <div class="border recipe">
        <div class="image" style="background-image:url('<?=$recipe["img"]?>');"></div>
        <div class="title"><?=$recipe["name"]?></div> 
        <div class="short_desc"><?=$recipe["short_description"]?></div> 
        <div class="time"><?=$recipe["time"]?></div> 
        <div class=""><a href="<?php // echo $recipe['slug'] ?>" class="btn btn-default">show more</a></div> 
    </div>
</div>
<?endforeach;?>
<?//print_r($recipes);;?>

</div>