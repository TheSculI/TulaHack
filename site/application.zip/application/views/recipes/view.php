<div class="row">
<div class="col-md-4">
    <img class="w-100" src="<?=$recip_item["img"]?>">
</div>
<div class="col-md-4">
Состав :
</div>
<div class="col-md-4">
    <?=$recip_item["recipe"]?>
</div>
</div>
<?=$recip_item["long_description"]?>